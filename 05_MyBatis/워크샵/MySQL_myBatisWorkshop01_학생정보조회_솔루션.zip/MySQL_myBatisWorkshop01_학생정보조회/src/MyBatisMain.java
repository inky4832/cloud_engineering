import java.util.List;
import java.util.Scanner;

import com.dto.StudentDTO;
import com.service.MyBatisServiceImpl;

public class MyBatisMain {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		while (true) {
			printMainMenu();
			String inputMenu = scan.next();
		    switch(inputMenu) {
		    
		    case "0": exit(); break;
		    case "1": printSelectAllStudent(); break;
		    
		    }
		} // end while

	}// end main

	private static void exit() {
		System.out.println("프로그램이 종료되었습니다.");
		System.exit(0);
	}
	
	private static void printSelectAllStudent(){
		
		MyBatisServiceImpl service = new MyBatisServiceImpl();
		List<StudentDTO> list = service.selectAllStudent();
		System.out.println("====================================================================================");
		System.out.println("학번\t이름\t주민번호\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("------------------------------------------------------------------------------------");
		for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",dto.getStuNo(),dto.getStuName(),dto.getStuSsn(),dto.getStuAddress(),dto.getEntDate(),dto.getAbsYn());
		}
	   System.out.printf("총 학생수: %d 명 \n" , list.size());
	}
	
	
	private static void printMainMenu() {

		System.out.println("*****************************************");
		System.out.println("\t[학생 정보 관리 메뉴]");
		System.out.println("*****************************************");
		System.out.println("1.전체 학생 목록");
		System.out.println("0.종료");
		System.out.println("*****************************************");
		System.out.print("메뉴 입력 => ");
	}//
	
	
	
	
}// end class
