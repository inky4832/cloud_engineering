package com.servlet;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/LifeCycleServlet")
public class LifeCycleServlet extends HttpServlet {

	//인스턴스 변수
	//int num;
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init 호출");
	}
	public void destroy() {
		System.out.println("destroy 호출");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// 특정사용자만 사용할 수 있도록 모든 변수는 로컬변수로 만들자.
		int num=0;
		System.out.println("doGet 호출.......222");
		
	}

}
